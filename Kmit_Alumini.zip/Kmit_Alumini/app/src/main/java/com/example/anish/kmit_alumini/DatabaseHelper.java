package com.example.anish.kmit_alumini;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by anish on 21/3/17.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME=" KMITALUMINI.db";
    public static final String TABLE_NAME=" Register";
    public static final String  Col_1= "Name";
    public static final String Col_2= "Email";
    public static final String Col_3= "Password";
    public static final String Col_4= "Hallticket";
    public static final String Col_5=" Age";


    public DatabaseHelper(Context context)
    {
        super(context,DATABASE_NAME,null,1);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_String = "CREATE TABLE " + TABLE_NAME + "(" + Col_1 + " TEXT," + Col_2 + " TEXT," + Col_3 + " TEXT" + Col_4 + "TEXT PRIMARY KEY" + Col_5 + " INT" + ")";
       db.execSQL(SQL_String);
    }
    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion ) {
   db.execSQL("DROP TABLE IF EXISTS" +TABLE_NAME);
            onCreate(db);

    }

    public boolean insertData(String Name, String Email, String Password, String Hallticket, String Age)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(Col_1,Name);
        contentValues.put(Col_2,Email);
        contentValues.put(Col_3,Password);
        contentValues.put(Col_4,Hallticket);
        contentValues.put(Col_5,Age);
        long result= db.insert(TABLE_NAME,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;



    }
}
