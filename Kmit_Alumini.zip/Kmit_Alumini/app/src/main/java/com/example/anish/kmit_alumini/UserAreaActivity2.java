package com.example.anish.kmit_alumini;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * Created by anish on 26/6/17.
 */

public class UserAreaActivity2 extends AppCompatActivity{
  Button b2;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_user_area2);

        b2=(Button)findViewById(R.id.page2);

                b2.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {

                            Intent page2=new Intent(UserAreaActivity2.this,UserAreaActivity3.class);
                            UserAreaActivity2.this.startActivity(page2);
                }
        });


        }

    }

