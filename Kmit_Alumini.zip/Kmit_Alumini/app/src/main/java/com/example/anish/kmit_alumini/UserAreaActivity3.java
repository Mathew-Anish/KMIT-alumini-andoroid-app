package com.example.anish.kmit_alumini;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

/**
 * Created by anish on 26/6/17.
 */

public class UserAreaActivity3 extends AppCompatActivity{
Button b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_area3);

        b3=(Button)findViewById(R.id.page3);

        b3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent page3=new Intent(UserAreaActivity3.this,UserAreaActivity4.class);
                        UserAreaActivity3.this.startActivity(page3);
            }
        });

    }

}

