package com.example.anish.kmit_alumini;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;


public class UserAreaActivity extends AppCompatActivity {
Button bpage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_area);

        bpage= (Button)findViewById(R.id.page1);

    bpage.setOnClickListener(new View.OnClickListener() {
    public void onClick (View v)
    {
       Intent page1 = new Intent( UserAreaActivity.this,UserAreaActivity2.class);
        UserAreaActivity.this.startActivity(page1);
    }
});
    }
    }
