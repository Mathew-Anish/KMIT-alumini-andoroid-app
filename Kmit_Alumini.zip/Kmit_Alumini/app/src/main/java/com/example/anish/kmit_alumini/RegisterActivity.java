package com.example.anish.kmit_alumini;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
   Button bRegister;
    EditText  etName,etEmail,etPassword,etHallTicket,etAge;
DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



         EditText  etName =(EditText) findViewById(R.id.etName);
         EditText  etEmail =(EditText) findViewById(R.id.etEmail);
         EditText  etPassword =(EditText) findViewById(R.id.etPassword);
         EditText  etHallTicket =(EditText) findViewById(R.id.etHallTicket);
         EditText  etAge =(EditText) findViewById(R.id.etAge);

         bRegister  =(Button) findViewById(R.id.bRegister);
        myDb=new DatabaseHelper(this);
    addData();


        bRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent userPage =new Intent(RegisterActivity.this,UserAreaActivity.class);
                RegisterActivity.this.startActivity(userPage);


            }

                    });
                 }
    public void addData()
    {
      bRegister.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
             boolean isInserted= myDb.insertData(etName.getText().toString(),etEmail.getText().toString(),etPassword.getText().toString(),
                      etHallTicket.getText().toString(),etAge.getText().toString());

              if(isInserted==true)
                  Toast.makeText(RegisterActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();

          }
      });
                       }
                }
